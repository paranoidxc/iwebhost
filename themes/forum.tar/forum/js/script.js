$(document).ready(function(){
  $('.timeago').timeago();
});